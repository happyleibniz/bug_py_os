# Minecraft_python_Edition
Minecraft using pygame opengl pyglet from PYTHON

REQUIREMENTS:

```pyopengl==3.1.5```

```pyglet==1.5.28```

```numpy==1.19.3```

```pygame==2.0.1```

keys:

```w```:player move forward

```a```:player move left

```s```:player move back

```d```:player move right

```e```:inventory

```Esc```:pause the game ⏸️


⚠️WARNING⚠️

THIS PROGRAM IS STILL TESTING⚠️

COMPONENTS MIGHT BREAK OR CRASH

If you find any issue please let me know📞(or email me 📧

要求：

```PyOpenGL版本号3.1.5 版本```

```pyglet版本号1.5.28```

```NumPy版本号1.19.3```

```Pygame 版本号2.0.1```

keys：

```w```：玩家前进

```a```：玩家向左移动

```s```:player 移动到后边

```d```:玩家向右移动

```e```：库存

```Esc```：暂停游戏⏸️

⚠️警告⚠️

此程序仍在测试中⚠️

组件可能损坏或崩溃

如果您发现任何问题，请告诉我📞(or email me📧
